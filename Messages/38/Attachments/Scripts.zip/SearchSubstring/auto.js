var fso = new ActiveXObject("Scripting.FileSystemObject");
if (WSH.Arguments.count() < 1 || !fso.FileExists(WSH.Arguments(0)))
{
	WSH.Echo("open ReadMe");
	WScript.Quit();
}
var inputfile = fso.OpenTextFile(WSH.Arguments(0));
var input = inputfile.ReadAll();
var str = WSH.Arguments(1);
inputfile.Close();
WSH.Echo("Automat");
function createAutomaton(str)
{
	var alphabet = [],
		automaton = [];
	for(var i=0; i<str.length; i++)
	{
		alphabet[str.charAt(i)] = 1;
		automaton[i] = [];
	}
	automaton[str.length] = [];

	for(var letter in alphabet)
		automaton[0][letter] = 0;

	for(var state=0; state<str.length; state++)
	{
		var prev = automaton[state][str.charAt(state)];
		automaton[state][str.charAt(state)] = state + 1;
		for(var letter in alphabet)
			automaton[state + 1][letter] = automaton[prev][letter];
	}
	var lenght = 0;
	return automaton;
}

function printAutomaton(automaton)
{
	var output = [' '];
	for(var letter in automaton[0])
		output.push(letter);
	var delimLength = (output.join(' | ') + ' |').length;
	WSH.Echo(output.join(' | ') + ' |');
	var delim = "";
	for (var i = 0; i < delimLength; i++)
		delim += "-"
	WSH.Echo(delim);
	for(var state=0; state<automaton.length; state++)
	{
		var output = [state];
		for(var letter in automaton[state])
			output.push(automaton[state][letter]);
		WSH.Echo(output.join(' | ') + ' |');
		var str = output.join(' | ');
		var delim = "";
		for (var i = 0; i < str.length + 2; i++)
			delim+= "-";
		WSH.Echo(delim);
	}
}
var startTime = new Date();

var lengthSub = str.length;
var lengthText = input.length;
var auto = createAutomaton(str);
printAutomaton(auto);
var j=0;
var x = Number.MAX_VALUE;
if (WSH.Arguments.count() > 2)
	x = WSH.Arguments(2);
var count = 0;
var outputLine = "";
for (i=0; i < lengthText; i++) 
{
	if (auto[j][input.charAt(i)] != null)
		j=auto[j][input.charAt(i)];
	else
		j = 0;
	if (j >= lengthSub)
	{
		if (count < x)
		{
			outputLine += (i-lengthSub+1 + " ");
			count++;
		}
	}
}
var endTime = new Date();
if (outputLine.length == 0)
		WSH.echo("Not found");
	else
		WSH.echo(outputLine);
WSH.Echo("Time = " + (endTime - startTime) + " ms");