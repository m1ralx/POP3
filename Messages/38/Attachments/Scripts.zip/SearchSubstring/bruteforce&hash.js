var fso = new ActiveXObject("Scripting.FileSystemObject");
if (WSH.Arguments.count() < 1 || !fso.FileExists(WSH.Arguments(0)))
{
	WSH.Echo("open ReadMe");
	WScript.Quit();
}

var quadHash = [];
for (var i = 0; i < 1104; i++)
{
	quadHash[i] = i * i ;
}
var n = Number.MAX_VALUE;
if (WSH.Arguments.count() > 2)
	n = WSH.Arguments(2);
	
function bf (input, sub)
{
	WSH.echo("BruteForce Algorithm");
	var countOfInd = 0;
	var outputLine = "";
	var startTime = new Date();
	for (var i = 0; i < input.length - sub.length + 1; i++)
	{
		var count = 0;
		str = input.substring(i, sub.length);
		for (var j = 0; j < sub.length; j++)
			if (input.charAt(i+j) == sub.charAt(j))
				count++;
		if (count == sub.length)
			if (countOfInd < n)
			{
				outputLine += (i + " ");
				countOfInd++;
			}
	}
	if (outputLine.length == 0)
		WSH.echo("Not found");
	else
		WSH.echo(outputLine);
	var endTime = new Date();
	WSH.echo("Time = " + (endTime - startTime) + " ms");
}
function hash(input, sub, variable)
{
	if (variable == 1)
		WSH.echo("Hash #1 line");
	else
		WSH.echo("Hash #2 quad");
	var startTime = new Date();
	var countOfInd = 0;
	var hash = 0;
	for (var i = 0; i < sub.length; i++)
	{
		if (variable == 1)
			hash += sub.charCodeAt(i);
		if (variable == 2)
			hash += quadHash[sub.charCodeAt(i)];
	}
	var outputLine = "";
	var collis = 0;
	for (var i = 0; i < input.length - sub.length + 1; i++)
	{
		str = input.substr(i, sub.length);
		var hashfind = 0;
		for (var j = 0; j < str.length; j++)
		{
			if (variable == 1)
				hashfind += str.charCodeAt(j);
			if (variable == 2)
				hashfind += quadHash[str.charCodeAt(j)];
		}
		if (hashfind == hash)
		{
			if (sub != str)
				collis++;
			else
				if (countOfInd < n)
				{
					outputLine += (i + " ");
					countOfInd++;
				}
		}
	}
	if (outputLine.length == 0)
		WSH.echo("Not found");
	else
		WSH.echo(outputLine);
	WSH.echo("collision : " + collis);
	var endTime = new Date();
	WSH.echo("Time = " + (endTime - startTime) + " ms");
}

function newHash (firstSymb, endSymb, oldHash,maxDeg)
{
	return ((( oldHash -  firstSymb.charCodeAt(0) * maxDeg ) << 1 ) + endSymb.charCodeAt(0));
}
function karp_rabin (input, sub)
{
	WSH.echo("Rabin_Karp algorithm");
	var countOfInd = 0;
	var startTime = new Date();
	var maxDeg = 1;
	var collis = 0;
	for (var i = 1; i < sub.length; i++)
		maxDeg = maxDeg << 1;
	var hashSub = hashNow = 0;
	for (var i = 0; i < sub.length; i++)
	{
		hashSub = ((hashSub << 1) + sub.charCodeAt(i));;
		hashNow = ((hashNow << 1) + input.charCodeAt(i));;
	}
	var outputLine = "";
	for (var i = sub.length; i <= input.length ; i++)
	{
		if (hashSub == hashNow)
		{
			if (input.substr(i - sub.length, sub.length) == sub)
				if (countOfInd < n)
				{
					outputLine += ((i - sub.length) + " ");
					countOfInd++;
				}
			else
				collis++;
		}
		if (i == input.length)
			break;
		hashNow = newHash(input.charAt(i-sub.length), input.charAt(i), hashNow, maxDeg);
	}
	if (outputLine.length == 0)
		WSH.echo("Not found");
	else
		WSH.echo(outputLine);
	WSH.echo("collision = " + collis);
	var endTime = new Date();
	WSH.echo("Time = " + (endTime - startTime) + " ms");
}

var inputfile = fso.OpenTextFile(WSH.Arguments(0));
var input = inputfile.ReadAll();
var sub = WSH.Arguments(1);
inputfile.Close();
bf(input, sub);
WSH.echo("------------------------");
hash(input, sub, 1);
WSH.echo("------------------------");
hash(input, sub, 2);
WSH.echo("------------------------");
karp_rabin(input, sub);