var fso = new ActiveXObject("Scripting.FileSystemObject");
if (WSH.Arguments.count() < 1 || !fso.FileExists(WSH.Arguments(0)))
{
	WSH.Echo("open ReadMe");
	WScript.Quit();
}
var inputfile = fso.OpenTextFile(WSH.Arguments(0));
var input = inputfile.ReadAll();
var sub = WSH.Arguments(1);
inputfile.Close();
WSH.Echo("BM-Search");
var n = Number.MAX_VALUE;
if (WSH.Arguments.count() > 2)
	n = WSH.Arguments(2);
function prefixFunc (sub)
{
	var l = sub.length;
	var pref = [];
	pref[0] = 0;
	var count = 0;
	for (var i = 1; i < l; i++)
	{
		while ( (count > 0) && (sub.charAt(count) != sub.charAt(i)))
			count = pref[count - 1];
		if (sub.charAt(count) == sub.charAt(i))
			count++;
		pref[i] = count;
	}
	return pref;
}
var startTime = new Date();

var lengthSub = sub.length;
var prefix = [];
var prefix1 = [];
prefix = prefixFunc(sub);

reversSub = sub.split("").reverse().join("");
prefix1 = prefixFunc(reversSub);

var suff = [];
for (var i=0; i < lengthSub + 1; i++)
	suff[i] = lengthSub - prefix[prefix.length - 1];
for (var i = 1; i < lengthSub; i++)
{
	var j = prefix1[i];
	suff[j] = Math.min(suff[j],  i - prefix1[i] + 1);
}
suff[0] = 1;
var stopSymb = [];
for (var i = 0; i < lengthSub; i++)
	stopSymb[sub.charAt(i)]=lengthSub;
stopSymb['other'] = lengthSub;

for (var i = 0; i < lengthSub-1; i++)
{
		stopSymb[sub.charAt(i)] = lengthSub- i - 1;
}
var count = 0;
var outputLine = "";
for (var shift = 0; shift <= input.length - lengthSub;)
{
	var pos = lengthSub - 1;
	
	while (sub.charAt(pos) == input.charAt(pos + shift))
	{
		
		if (pos == 0)
			if (count < n)
			{
				outputLine += shift + " ";
				count++;
			}
		pos--;
		if (pos < 0)
			break;
	}
	if (stopSymb[input.charAt(pos - shift)] == null)
		stopSymb[input.charAt(pos - shift)] = stopSymb['other'];
	shift += Math.max(suff[lengthSub - pos - 1], pos - stopSymb[input.charAt(pos - shift)]);
}
var endTime = new Date();
WSH.Echo(outputLine);
WSH.Echo("Time = " + (endTime -startTime) + " ms");