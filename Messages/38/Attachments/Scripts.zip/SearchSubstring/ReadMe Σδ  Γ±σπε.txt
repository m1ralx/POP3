1)bruteforce&hash.js
	Пример запуска: cscript bruteforce.js input.txt pattern [n]
	Реализован поиск подстроки в строке с помощью алгоритма BruteForce и
	с помощью трёх различных хэш-функций.
2)Boyer-moor.js
	Пример запуска: cscript Boyer-moor.js input.txt pattern [n]
	Реализован поиск подстроки в строке с помощью алгоритма Бойера - Мура.
3) auto.js
	Пример запуска: cscript auto.js input.txt pattern [n]
	Реализован поиск подстроки в строке с помощью алгоритма Ахо - Корасика
	(построение ДКА).