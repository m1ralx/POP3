ReadMe
The program transfers expression from an infix form of record in postfix and back depending on argument, 
transferred at start via the console.
start example:
cscript RPN toInfix (or toPostfix) input.txt output.txt

~ - unary minus
