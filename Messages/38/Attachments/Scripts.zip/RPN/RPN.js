var fso = new ActiveXObject("Scripting.FileSystemObject");
function arrPriorities()
{
	var priority = [];
	priority['('] = -1;
	priority[')'] = 0;
	priority['+'] = priority['-']=1;
	priority['*'] = priority['/']=2;
	priority['^'] = 3;
	priority['~'] = 5;
	return priority;
}
function toPostfix(inputLine)
{
	var l = inputLine.length;
	var openBrackets = 0, closeBrackets = 0, operands = 0, operators = 0;
	var stack = [];
	var outputLine = [];
	var priority = arrPriorities();
	function action(operation)
	{
		while (priority[stack[0]] >= priority[operation])
			{
				outputLine.push(stack[0]);
				stack.shift();
			}							
		stack.unshift(inputLine[i]);
	}
	for (var i = 0; i < l; i++)
	{
			if (!(inputLine[i] in priority)) 
				outputLine.push(inputLine[i]);
			else
			{
				switch (inputLine[i])
				{
					case '+':
					{
						action('+');
						continue;
					}
					case '-':
					{
						if (i == 0 || inputLine[i-1] === '(') 
						{
							stack.unshift("~");
						}
						else
						{
							while (priority[stack[0]] >= priority['-'] && stack[0] != '(')
							{
								outputLine.push(stack[0]);
								stack.shift();
							}
							stack.unshift(inputLine[i]); 
						}
						continue;
					}
					case '*':
					{
						action('*');
						continue;
					}
					case '/':
					{
						action('/');
						continue;
					}
					case '^':
					{					
						stack.unshift(inputLine[i]);
						continue;
					}
					
					case '(':
					{
						stack.unshift(inputLine[i]);
						continue;
					}
					case ')':
					{
						for (var j = 0; j < stack.length; j++)
							if (stack[j] == '(' )
							{
								var pos = j;
								break;
							}
						for (var j = 0; j < pos; j++)
							outputLine.push(stack[j]);
					
						for (var j = 0; j <= pos; j++)
							stack.shift();
						continue;
					}
				}
			}
			//WSH.Echo(outputLine);
	}
	outputLine = outputLine.concat(stack);
	for (var k = 0; k < stack.length; k++)
			stack.shift();
	return outputLine.join("");
}
function toInfix(inputLine)
{
	var l = inputLine.length;
	var stack = [];
	var outputLine = [];
	var priority = arrPriorities();
	var j = -1;
	for (var i = 0; i < l; i++)
	{
		//WSH.Echo(stack + " " + j + " " + stack[j] + " " + inputLine[i]);
		if (inputLine[i] == '~')
		{
			if (i == inputLine.length - 1 || (inputLine[i+1] in priority))
				if (j < 2)
					stack[j] = '(' + '-' + stack[j] + ')' ;
				else
					stack[j] = '-' + '(' + stack[j] + ')' ;
			else
				if (j < 3)
					stack[j] = '-' + stack[j] ;
				else
					stack[j] = '-' + '(' + stack[j] + ')';
			continue;
		}
		if (inputLine[i] in priority)
		{
			if (priority[j]<priority[inputLine[i]])
				stack[j] = '(' + stack[j] + ')';
			if (priority[j-1] < priority[inputLine[i]])
				stack[j-1] = '(' + stack[j-1] + ')';
				
			stack[j-1] = stack[j-1] + inputLine[i] + stack[j];
			priority[j-1] = priority[inputLine[i]];
			j--;
		}
		else
		{
			j++;
			stack[j] = inputLine[i];
			priority[j] = 4;
		}
		
	}
	var outputLine = stack[0].split("");
	
	return stack[0];
}

if (WSH.Arguments.count() == 0)
{
	WScript.StdOut.Write("Example of start of the program: cscript RPN.js toInfix (or toPostfix) input.txt output.txt");
	WScript.Quit();
}
if (WSH.Arguments.count()> 2)
	if (fso.FileExists(WSH.Arguments(1)))
		{
			var file = fso.OpenTextFile(WSH.Arguments(1));
			var text = file.ReadAll();
			file.Close();
			var inputLine = text.split("");
		}
		else
		{
			WScript.StdOut.Write('input file are not exist');
			WScript.Quit();
		}
else
{
	WScript.StdOut.Write("Example of start of the program: cscript RPN.js toInfix (or toPostfix) input.txt output.txt");
	WScript.Quit();
}

var file = fso.CreateTextFile(WSH.Arguments(2), 2);
if (WSH.Arguments(0) == "toInfix")
{
	var str = toInfix(inputLine).split(""); //По мотивам Escape-кодирования.
	if (inputLine.join("") === toPostfix(str)) //сравниваются исходные данные и "закодированные-декодированные"
		file.Write(toInfix(inputLine));	
	else
		file.Write("syntax error");
}
else
{
	if (WSH.Arguments(0) == "toPostfix")
	{
		var str = toPostfix(inputLine).split("");
		if (inputLine.join("") == toInfix(str)) 
			file.Write(toPostfix(inputLine));
		else
			file.Write("syntax error");
	}
	else 
		WSH.Echo("Example of start of the program: cscript RPN.js toInfix (or toPostfix) input.txt output.txt");
}
file.Close();