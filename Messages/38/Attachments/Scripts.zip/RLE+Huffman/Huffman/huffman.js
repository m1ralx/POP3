var fso = new ActiveXObject("Scripting.FileSystemObject");
function Entropy(input, y)
{
	var alphabet = [];
	var freq = [];
	for(var i = 0;i < input.length; i++)
	{
		
		//if (input.charCodeAt(i) != 13)
			alphabet[input.charAt(i)]=0;
	}
		
	for(var i = 0; i < input.length; i++) 
	{
		//if (input.charCodeAt(i) != 13)
			alphabet[input.charAt(i)]++;
	}
	var file;
	if (y==0)
	{
		//file = fso.GetFile(WSH.Arguments(4));
		//file.Delete();
		file = fso.CreateTextFile(WSH.Arguments(4));
	}
	else
		file = fso.OpenTextFile(WSH.Arguments(4), 8);
	var n=0;
	for (var num in alphabet) 
		{    
			(freq[num])=(alphabet[num]/(input.length)); 
			n++; 
		} 
	if (n==1)
		file.Write('0'); 
	else
	{
		var Entropy = 0;
		for (var num in freq) 
			Entropy+=freq[num]*Math.log(freq[num])/Math.log(n); 
		if (y==0)
			file.WriteLine("Entropy inputline : " + (-Entropy));
		else
			file.WriteLine("Entropy outputline : " + (-Entropy));
			
		file.WriteLine("------------------");
	}
	file.Close();
	return alphabet;
}
function Node(left, right, letter, weight)
{
	this.Left = left;
	this.Right = right;
	this.Letter = letter;
	this.Weight = weight;
	this.Code = "";
}

function getSortedArray(alphabet) {
    var keys = []; 
	for(var key in alphabet) 
		keys.push(key);
    return keys.sort(function(a,b){
		return alphabet[a]-alphabet[b]
		});
}

function func(node)
{
	if (node.Letter.length == 1)
		tree[node.Letter] = node.Code;
	if (node.Left == null)
		return;
	node.Left.Code = node.Code + "0";
	node.Right.Code = node.Code + "1";
	func(node.Left);
	func(node.Right);
}

function getTree (input)
{
	var node = [];
	var alphabet = Entropy(input, y);
	y++;
	var a = getSortedArray(alphabet);
	var queue = [];
	for (var key in a)
		queue.push(a[key]);
	//WSH.Echo(queue);
	var j = 0;
	var count = 0;

	var arr = [];
	for (var i = 0; i < queue.length; i++)
	{
		tmpNode = new Node(null, null, queue[i], alphabet[queue[i]]);
		arr.push(tmpNode);
	}

	while (arr.length > 1)
	{
		var tmp1 = arr.shift();
		var tmp2 = arr.shift();
		var index = 0;
		var tmpNode = new Node(tmp1, tmp2, tmp1.Letter + tmp2.Letter, tmp1.Weight + tmp2.Weight);
		var count = 0;
		for (var i = 0; i < arr.length; i++)
		{
			if (arr[i].Weight >= tmpNode.Weight)
			{
				index = i;
				break;
			}
			count++;
		}
		if (count != arr.length && arr[arr.length - 1].Weight >= tmpNode.Weight)
		{
			var part1 = arr.slice(0, index);
			var part2 = arr.slice(index);
			part1.push(tmpNode);
			part1 = part1.concat(part2);
			arr = part1;
		}
		else
			arr.push(tmpNode);
	}
	var node = arr[0];
	func(node);
	var file = fso.CreateTextFile(WSH.Arguments(3));
	for (var key in tree)
	{
			file.Write(key + "9z");
			file.Write(tree[key] + "9z");
	}
}
function encode (input)
{
	var file = fso.CreateTextFile(WSH.Arguments(2));
	for (var i = 0; i < input.length; i++)
		file.Write(tree[input.charAt(i)]);
	file.Close();
}
function decode (input)
{
	tree = fso.OpenTextFile(WSH.Arguments(3));
	var line = tree.ReadAll();
	tree.Close();
	var res = line.split("9z");
	//WSH.Echo(res.length);
	var dict = [];
	
	for (var i = 0; i < res.length; i++)
		if (i % 2 == 0)
		{
			//WSH.Echo(res[i + 1]);
			//dict[res[i]] = res[i + 1];
			dict[res[i + 1]] = res[i];
		}
		
	var outputLine = "";
	
	file = fso.CreateTextFile(WSH.Arguments(2));
	var length = input.length;
	var a = new Date();
	WSH.Echo(a.getHours() + ":" + a.getMinutes() + ":" + a.getSeconds());
		var charCode = "";
		for (var i = 0; i < input.length; i++)
		{
			charCode += input.charAt(i);	
			if (dict[charCode] != null)
			{
					outputLine += dict[charCode];
					charCode = "";
			}
			if (outputLine.length == 1000)
			{
				file.Write(outputLine);
				outputLine = "";
			}
		}
		
		file.Write(outputLine);
		file.Close();
		var b = new Date();
		WSH.Echo(b.getHours() + ":" + b.getMinutes() + ":" + b.getSeconds());
}

var tree = [];
var y = 0;

if (WSH.Arguments.count() == 0)
{
	WSH.Echo("open ReadMe pls");
	WScript.Quit();
}
if (WSH.Arguments(0) == "encode")
{
	if (fso.FileExists(WSH.Arguments(1)))
	{
		var file = fso.OpenTextFile(WSH.Arguments(1));
		var input = file.ReadAll();
		file.Close();
		getTree(input);
		encode(input);
		var out = fso.OpenTextFile(WSH.Arguments(2));
		outLine = out.ReadAll();
		out.Close();
		Entropy(outLine, y);
		var entr = fso.OpenTextFile(WSH.Arguments(4), 8);
		entr.Write("compression ratio = " + (input.length * 8/outLine.length));
	}
	else
	{
		WSH.Echo("open ReadMe pls");
		WScript.Quit();	
	}
}
else
{
	if (WSH.Arguments(0) == "decode")
	{
		if (fso.FileExists(WSH.Arguments(1)) && fso.FileExists(WSH.Arguments(3)))
		{
			file = fso.OpenTextFile(WSH.Arguments(1));
			input = file.ReadAll();
			decode(input);
		}
		else
			WSH.Echo("open ReadMe pls");
	}
	else
		WSH.Echo("open ReadMe pls");
}