Пример запуска >cscript huffman.js encode input.txt output.txt tree.txt entropy.txt 
			   >cscript huffman.js decode input.txt output.txt tree.txt
Энтропия исходного текста, сжатого текста и коэффициент сжатия
записываются в файл entropy.txt. Символы исходного текста и их
коды записываются в файл tree.txt в порядке "Символ""Разделитель""Код",
где "Разделитель" - любая пара число-буква.