var fso = new ActiveXObject('Scripting.FileSystemObject');
function CharAt(index)
{
	var file = fso.OpenTextFile("ASCII.txt");
	var code = file.ReadAll();
	file.Close();
	return code.charAt(index);
}
function Index(character)
{
	var file = fso.OpenTextFile("ASCII.txt");
	var code = file.ReadAll();
	file.Close();
	for (var i = 0; i < code.length; i++)
		if (code.charAt(i) === character)
			return i;
}
function EscapeEncode(str)
{
	out = "";
	esc = WSH.Arguments(4);
	while (str.length > 0)
	{
		var i = 0;
		var chr = str.substring(0,1);
		for (var j = 0; j < str.length; j++)
			if (chr === str.charAt(i))
			{
				i++;
				if (chr != esc)
				{
					if (i == 258)
						break;
				}
				else
					if (i == 255)
						break;
			}
			else
				break;
		//WSH.Echo(i);
		if (i > 3)
		{
			if (chr != esc)
				out += esc + CharAt(i - 3) + chr;
			else
				out += esc + CharAt(i) + chr;
		}
		else
			if (chr != esc)
				for (var k = 0; k < i; k++)
					out += chr;
			else
				out += esc + CharAt(i) + chr;
		//WSH.Echo(str.substr(i));
		str = str.substr(i);
	}
	var fso = new ActiveXObject("Scripting.FileSystemObject"); // ������� ������
	var file = fso.CreateTextFile(WSH.Arguments(3), 2);	// ������� ����
	file.Write(out);
	file.Close();
	return;
}
function EscapeDecode(str)
{
	out = "";
	esc = WSH.Arguments(3);
	var count;
	for (var i = 0; i < str.length; i++)
	{	
		if (str.charAt(i) == esc)
		{
			if (str.charAt(i+2) != esc)
				for (var k = 0; k < Index(str.charAt(i + 1)) + 3; k++)
					out += str.charAt(i+2);
			else
				for (var k = 0; k < Index(str.charAt(i + 1)); k++)
					out += str.charAt(i+2);
			i += 2;
		}
		else
			out += str.charAt(i);
	}
	var file = fso.CreateTextFile(WSH.Arguments(3), 2);
	file.Write(out);
	file.Close();
}
function JumpEncode(str)
{
	out = "";
	while (str.length > 0)
	{
		var count1 = count2 = 1;
		var i = 1;
		while (str.charAt(i) == str.charAt(i-1) && i < str.length)
		{
			count1++;
			i++;
			if (count1 == 127)
				break;
		}
		var j = 1;
		while (str.charAt(j) != str.charAt(j-1) && j < str.length)
		{
			count2++;
			j++;
			if (count2 == 127)
				break;
		}
		if (count1 > 1)
			out += CharAt(count1) + CharAt(Index(str.charAt(0)));
		else
			out += CharAt(count2 + 128) + str.substr(0, count2)
		if (count1 > count2)
			var length = count1;
		else
			var length = count2;
		str = str.substring(length);
	}
	var file = fso.CreateTextFile(WSH.Arguments(3), 2);
	file.Write(out);
	file.Close();
}
function JumpDecode(str)
{
	
	var out = "";
	while (str.length  > 0)
	{
		//WSH.Echo(Index(str.charAt(0)));
		if (Index(str.charAt(0)) < 128)
		{
			for (var i = 0; i < Index(str.charAt(0)); i++)
				out += CharAt(Index(str.charAt(1)));
			str = str.substring(2);
		}
		else
		{
			out += str.substring(1, Index(str.charAt(0)) - 127)
			str = str.substring(Index(str.charAt(0)) - 127);
		}
	}
	var file = fso.CreateTextFile(WSH.Arguments(3), 2);
	file.Write(out);
	file.Close();
}

var file = fso.OpenTextFile(WSH.Arguments(2));
var str = file.ReadAll();
file.Close();
if (fso.FileExists(WSH.Arguments(2)))
{
	if (WSH.Arguments(0) == "Escape")
		if (WSH.Arguments(1) == "Encode")
			EscapeEncode(str);
		else
		{
			if (WSH.Arguments(1) == "Decode")
				EscapeDecode(str);
			else
				WSH.Echo("Run script: cscript RLE.js Escape/Jump Encode/Decode input.txt output.txt");
		}
	else
		if (WSH.Arguments(0) == "Jump")
			if (WSH.Arguments(1) == "Encode")
				JumpEncode(str);
			else
			{
				if (WSH.Arguments(1) == "Decode")
					JumpDecode(str);
				else
					WSH.Echo("Run script: cscript RLE.js Escape/Jump Encode/Decode input.txt output.txt");
			}
}
else
	WSH.Echo("Run script: cscript RLE.js Escape/Jump Encode/Decode input.txt output.txt");